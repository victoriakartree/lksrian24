<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;

class BarangController extends Controller
{
    public function index()
    {
        return Barang::select('id','nama_barang','stok','harga')->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_barang' =>'required',
            'stok'        =>'required',
            'harga'       =>'required',
            'deskripsi'   =>'required'
        ]);

        try{

            $barang = Barang::create([
                'nama_barang' => $request->nama_barang,
                'stok'        => $request->stok,
                'harga'       => $request->harga,
                'deskripsi'   => $request->deskripsi,
            ]);

            return response()->json([
                'message'=>'Barang Created Successfully!!'
            ]);
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while creating a barang!!'
            ],500);
        }
    }

    public function show($id)
    {
        $barang = Barang::findOrFail($id);

        return response()->json([
            'barang'=>$barang
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_barang' =>'required',
            'stok'        =>'required',
            'harga'       =>'required',
            'deskripsi'   =>'required'
        ]);

        $barang = Barang::findOrFail($id);

        try{

            $barang->update([
                'nama_barang' => $request->nama_barang,
                'stok'        => $request->stok,
                'harga'       => $request->harga,
                'deskripsi'   => $request->deskripsi,
            ]);

            return response()->json([
                'message'=>'Barang Updated Successfully!!'
            ]);

        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while updating a barang!!'
            ],500);
        }
    }

    public function destroy($id)
    {
        try {

            $barang = Barang::findOrFail($id);
            $barang->delete();

            return response()->json([
                'message'=>'Barang Deleted Successfully!!'
            ]);

        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while deleting a barang!!'
            ]);
        }
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomerController extends Controller
{
    public function index()
    {
        return Customer::select('id','nama_customer','nohp','email')->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_customer' =>'required',
            'nohp'          =>'required',
            'email'         =>'required',
            'alamat'        =>'required'
        ]);

        try{

            $customer = Customer::create([
                'nama_customer' => $request->nama_customer,
                'nohp'          => $request->nohp,
                'email'         => $request->email,
                'alamat'        => $request->alamat,
            ]);

            return response()->json([
                'message'=>'Customer Created Successfully!!'
            ]);
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while creating a customer!!'
            ],500);
        }
    }

    public function show($id)
    {
        $customer = Customer::findOrFail($id);

        return response()->json([
            'customer'=>$customer
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_customer' =>'required',
            'nohp'          =>'required',
            'email'         =>'required',
            'alamat'        =>'required'
        ]);

        $customer = Customer::findOrFail($id);

        try{

            $customer->update([
                'nama_customer' => $request->nama_customer,
                'nohp'          => $request->nohp,
                'email'         => $request->email,
                'alamat'        => $request->alamat,
            ]);

            return response()->json([
                'message'=>'Customer Updated Successfully!!'
            ]);

        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while updating a customer!!'
            ],500);
        }
    }

    public function destroy($id)
    {
        try {

            $customer = Customer::findOrFail($id);
            $customer->delete();

            return response()->json([
                'message'=>'Customer Deleted Successfully!!'
            ]);

        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while deleting a customer!!'
            ]);
        }
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaksi;
use App\Models\Barang;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
use PDF;

class TransaksiController extends Controller
{
    public function index()
    {
        return DB::table('tbl_transaksi as TS')
                   ->leftJoin('tbl_customer as TC', 'TC.id', '=', 'TS.id_customer')
                   ->select('TS.id', 'TS.no_transaksi', 'TS.tgl_transaksi', 'TS.total', 'TC.nama_customer')
                   ->get();
    }

    public function noTransaksi()
    {
        $query = DB::table('tbl_transaksi')
            ->select(DB::raw('RIGHT(no_transaksi,3) as no_transaksi', FALSE))
            ->orderBy('no_transaksi', 'DESC')
            ->limit(1)
            ->get();

        if($query->count() <> 0)
        {
            $data = $query->first();
            $kode = intval($data->no_transaksi) + 1;
        }
        else
        {
            $kode = 1;
        }

        $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodetampil = "NT-".$batas;
        return $kodetampil;
    }

    public function store(Request $request)
    {
        $request->validate([
            'no_transaksi'  =>'required',
            'id_customer'   =>'required',
            'id_barang'     =>'required',
            'tgl_transaksi' =>'required',
            'qty'           =>'required',
        ]);

        try{

            $barang = Barang::find($request->id_barang);

            if($request->qty > $barang->stok)
            {
                return response()->json([
                    'message'=>'Qty Melebihi Stok!!'
                ], 500);
            }
            else
            {
                $transaksi = Transaksi::create([
                    'no_transaksi'  => $request->no_transaksi,
                    'id_customer'   => $request->id_customer,
                    'id_barang'     => $request->id_barang,
                    'tgl_transaksi' => $request->tgl_transaksi,
                    'qty'           => $request->qty,
                    'total'         => $request->qty * $barang->harga,
                ]);

                $barang->stok -= $request->qty;
                $barang->save();

                return response()->json([
                    'message'=>'Transaksi Created Successfully!!'
                ]);
            }

        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Something goes wrong while creating a transaksi!!'
            ],500);
        }
    }

    public function show($id)
    {
        $transaksi = DB::table('tbl_transaksi as TS')
                         ->leftJoin('tbl_customer as TC', 'TC.id', '=', 'TS.id_customer')
                         ->leftJoin('tbl_barang as TB', 'TB.id', '=', 'TS.id_barang')
                         ->select('TS.*', 'TC.nama_customer', 'TB.nama_barang', 'TB.harga')
                         ->where('TS.id', $id)
                         ->get();

        return response()->json([
            'transaksi'=>$transaksi
        ]);
    }

    public function cetak($id)
    {
    	$transaksi = DB::table('tbl_transaksi as TS')
                         ->leftJoin('tbl_customer as TC', 'TC.id', '=', 'TS.id_customer')
                         ->leftJoin('tbl_barang as TB', 'TB.id', '=', 'TS.id_barang')
                         ->select('TS.*', 'TC.nama_customer', 'TB.nama_barang', 'TB.harga')
                         ->where('TS.id', $id)
                         ->get();

        return response()->json([
            'transaksi'=>$transaksi
        ]);

        // $pdf = PDF::loadview('karyawan.cetak', ['transaksi' => $transaksi]);
        // return $pdf->download('laporan-transaksi.pdf');
    }
}

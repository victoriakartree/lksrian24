<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\TransaksiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('/login', App\Http\Controllers\Api\LoginController::class)->name('login');
Route::post('/logout', App\Http\Controllers\Api\LogoutController::class)->name('logout');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Data User
Route::get('/datauser', [UserController::class, 'index']);
Route::post('/datauser/store', [UserController::class, 'store']);
Route::get('/datauser/show/{id}', [UserController::class, 'show']);
Route::patch('/datauser/update/{id}', [UserController::class, 'update']);
Route::delete('/datauser/destroy/{id}', [UserController::class, 'destroy']);

// Data Customer
Route::get('/customer', [CustomerController::class, 'index']);
Route::post('/customer/store', [CustomerController::class, 'store']);
Route::get('/customer/show/{id}', [CustomerController::class, 'show']);
Route::patch('/customer/update/{id}', [CustomerController::class, 'update']);
Route::delete('/customer/destroy/{id}', [CustomerController::class, 'destroy']);

// Data Barang
Route::get('/barang', [BarangController::class, 'index']);
Route::post('/barang/store', [BarangController::class, 'store']);
Route::get('/barang/show/{id}', [BarangController::class, 'show']);
Route::patch('/barang/update/{id}', [BarangController::class, 'update']);
Route::delete('/barang/destroy/{id}', [BarangController::class, 'destroy']);

// Data Transaksi
Route::get('/transaksi', [TransaksiController::class, 'index']);
Route::get('/getNoTransaksi', [TransaksiController::class, 'noTransaksi']);
Route::post('/transaksi/store', [TransaksiController::class, 'store']);
Route::get('/transaksi/show/{id}', [TransaksiController::class, 'show']);
Route::get('/transaksi/cetak/{id}', [TransaksiController::class, 'cetak']);

import React from 'react';
import { Switch, Route } from "react-router-dom";

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

import ListUser from './pages/master/user/ListUser';
import CreateUser from './pages/master/user/CreateUser';
import EditUser from './pages/master/user/EditUser';

import ListCustomer from './pages/master/customer/ListCustomer';
import CreateCustomer from './pages/master/customer/CreateCustomer';
import EditCustomer from './pages/master/customer/EditCustomer';

import ListBarang from './pages/master/barang/ListBarang';
import CreateBarang from './pages/master/barang/CreateBarang';
import EditBarang from './pages/master/barang/EditBarang';

import ListTransaksi from './pages/transaksi/ListTransaksi';
import CreateTransaksi from './pages/transaksi/CreateTransaksi';
import DetailTransaksi from './pages/transaksi/DetailTransaksi';
import CetakTransaksi from './pages/transaksi/CetakTransaksi';

function App() {

  return (
		<Switch>
			<Route exact path="/" component={Login} />	
			<Route exact path="/dashboard" component={Dashboard} />
			
			{/* Data User */}
			<Route exact path="/listuser" component={ListUser} />
			<Route exact path="/createuser" component={CreateUser} />
			<Route exact path="/edituser/:id" component={EditUser} />

			{/* Data Customer */}
			<Route exact path="/listcustomer" component={ListCustomer} />
			<Route exact path="/createcustomer" component={CreateCustomer} />
			<Route exact path="/editcustomer/:id" component={EditCustomer} />

			{/* Data Barang */}
			<Route exact path="/listbarang" component={ListBarang} />
			<Route exact path="/createbarang" component={CreateBarang} />
			<Route exact path="/editbarang/:id" component={EditBarang} />

			{/* Data Transaksi */}
			<Route exact path="/listtransaksi" component={ListTransaksi} />
			<Route exact path="/createtransaksi" component={CreateTransaksi} />
			<Route exact path="/detail/:id" component={DetailTransaksi} />
			<Route exact path="/cetak/:id" component={CetakTransaksi} />
		</Switch>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

function Login() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    
    const [validation, setValidation] = useState([]);

    const history = useHistory();

    useEffect(() => {

        if(localStorage.getItem('token')) {

            history.push('/dashboard');
        }
    }, []);

    const loginHandler = async (e) => {
        e.preventDefault();

        const formData = new FormData();

        formData.append('email', email);
        formData.append('password', password);

        await axios.post('http://127.0.0.1:8000/api/login', formData)
        .then((response) => {

            localStorage.setItem('token', response.data.token);

            Swal.fire({
                icon:"success",
                text:response.data.message
            })
            
            history.push('/dashboard');
        })
        .catch((error) => {

            setValidation(error.response.data);
        })
    };

    return (

        <div class="container-xxl">
            <div class="authentication-wrapper authentication-basic container-p-y">
                <div class="authentication-inner">
                    <div class="card">
                        <div class="card-body">
                            <div class="app-brand justify-content-center">
                                <Link to={'#'} class="app-brand-link gap-2">
                                    <span class="app-brand-logo demo"></span>
                                    <span class="app-brand-text demo text-body fw-bolder">Silahkan Login</span>
                                </Link>
                            </div>
                            {
                                validation.message && (
                                    <div className="alert alert-danger">
                                        {validation.message}
                                    </div>
                                )
                            }
                            <Form onSubmit={loginHandler} id="formAuthentication" class="mb-3">
                                <div class="mb-3">
                                    <Form.Label for="email" class="form-label">Email</Form.Label>
                                    <Form.Control type="email" placeholder="Email ..." value={email} onChange={(event)=>{setEmail(event.target.value)}}/>
                                </div>
                                {
                                    validation.email && (
                                        <div className="alert alert-danger">
                                            {validation.email[0]}
                                        </div>
                                    )
                                }
                                <div class="mb-3 form-password-toggle">
                                    <div class="d-flex justify-content-between">
                                        <Form.Label class="form-label" for="password">Password</Form.Label>
                                    </div>
                                    <div class="input-group input-group-merge">
                                        <Form.Control type="password" placeholder="Password ..." value={password} onChange={(event)=>{setPassword(event.target.value)}}/>
                                    </div>
                                </div>
                                {
                                    validation.password && (
                                        <div className="alert alert-danger">
                                            {validation.password[0]}
                                        </div>
                                    )
                                }
                                <div class="mb-3">
                                    <Button className="btn btn-primary d-grid w-100" type="submit">Sign in</Button>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )

}

export default Login;
import React, { useEffect, useState } from "react";
import Form from 'react-bootstrap/Form'
import { useParams } from 'react-router-dom'
import axios from 'axios';
import Swal from 'sweetalert2';
import { useHistory } from 'react-router';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';

import Header from '../../../templates/Header';
import Sidebar from '../../../templates/Sidebar';

function EditBarang() {

    const history = useHistory();

    const { id } = useParams()
    
    const [nama_barang, setNamaBarang] = useState("")
    const [stok, setStok] = useState("")
    const [harga, setHarga] = useState("")
    const [deskripsi, setDeskripsi] = useState("")
    const [validationError,setValidationError] = useState({})

    useEffect(()=>{
        fetchDataBarang()
    },[])

    const fetchDataBarang = async () => {
        await axios.get(`http://127.0.0.1:8000/api/barang/show/${id}`).then(({data})=>{
        const { nama_barang, stok, harga, deskripsi } = data.barang
            setNamaBarang(nama_barang)
            setStok(stok)
            setHarga(harga)
            setDeskripsi(deskripsi)
        }).catch(({response:{data}})=>{
        Swal.fire({
            text:data.message,
            icon:"error"
        })
        })
    }

    const updateBarang = async (e) => {
        e.preventDefault();

        const formData = new FormData()
        formData.append('_method', 'PATCH');
        formData.append('nama_barang', nama_barang)
        formData.append('stok', stok)
        formData.append('harga', harga)
        formData.append('deskripsi', deskripsi)

        await axios.post(`http://127.0.0.1:8000/api/barang/update/${id}`, formData).then(({data})=>{
        Swal.fire({
            icon:"success",
            text:data.message
        })
        history.push('/listbarang');
        }).catch(({response})=>{
        if(response.status===422){
            setValidationError(response.data.errors)
        }else{
            Swal.fire({
            text:response.data.message,
            icon:"error"
            })
        }
        })
    }

    return (
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <Sidebar />
        
            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Edit Data Barang</h4>
                        <div class="row">
                            <div class="col-xl">
                                <div class="card mb-12">
                                    {
                                        Object.keys(validationError).length > 0 && (
                                            <div className="row">
                                                <div className="col-12">
                                                    <div className="alert alert-danger">
                                                        <ul className="mb-0">
                                                            {
                                                            Object.entries(validationError).map(([key, value])=>(
                                                                <li key={key}>{value}</li>   
                                                            ))
                                                            }
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    }
                                    <Form onSubmit={updateBarang}>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <Form.Label>Nama Barang</Form.Label>
                                            <Form.Control type="text" placeholder="Nama Barang ..." required value={nama_barang} onChange={(event)=>{setNamaBarang(event.target.value)}}/>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Stok</Form.Label>
                                            <InputGroup className="mb-3">
                                                <Form.Control type="number" placeholder="Stok ..." required value={stok} onChange={(event)=>{setStok(event.target.value)}} />
                                                <InputGroup.Text>Pcs</InputGroup.Text>
                                            </InputGroup>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Harga</Form.Label>
                                            <InputGroup className="mb-3">
                                                <InputGroup.Text>Rp</InputGroup.Text>
                                                <Form.Control type="number" placeholder="Harga ..." required value={harga} onChange={(event)=>{setHarga(event.target.value)}} />
                                            </InputGroup>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Deskripsi</Form.Label>
                                            <Form.Control as="textarea" placeholder="Deskripsi ..." style={{ height: '100px' }} required value={deskripsi} onChange={(event)=>{setDeskripsi(event.target.value)}}/>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <Button className="btn btn-primary" type="submit"><i className="bx bx-save"></i> Save Changes</Button> &nbsp;&nbsp;
                                        <Link className="btn btn-danger" to={"/listbarang"}><i className="bx bx-undo"></i> Cancel</Link>
                                    </div>
                                    </Form>
                                </div>
                            </div>        
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    )

}

export default EditBarang;
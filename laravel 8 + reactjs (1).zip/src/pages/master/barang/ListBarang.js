import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button'
import axios from 'axios';
import Swal from 'sweetalert2';

import Header from '../../../templates/Header';
import Sidebar from '../../../templates/Sidebar';

function ListBarang() {

    const [databarang, setDataBarang] = useState([])

    useEffect(()=>{
        fetchDataBarang() 
    },[])

    const fetchDataBarang = async () => {
        await axios.get(`http://127.0.0.1:8000/api/barang`).then(({data})=>{
            setDataBarang(data)
        })
    }

    const deleteBarang = async (id) => {
        const isConfirm = await Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            return result.isConfirmed
          });

          if(!isConfirm){
            return;
          }

          await axios.delete(`http://127.0.0.1:8000/api/barang/destroy/${id}`).then(({data})=>{
            Swal.fire({
                icon:"success",
                text:data.message
            })
            fetchDataBarang()
          }).catch(({response:{data}})=>{
            Swal.fire({
                text:data.message,
                icon:"error"
            })
          })
    }

	return (
		
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <Sidebar />
        
            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Data Barang</h4>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Data Barang</h5>
                                <Link to={"/createbarang"} class="btn btn-sm btn-primary float-end"><i class="bx bx-plus"></i> Tambah Data</Link>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive text-nowrap">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Stok</th>
                                                <th>Harga</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                  				databarang.length > 0 && (
													databarang.map((row, key)=>(
                                            <tr key={key}>
                                                <td>{key + 1}</td>
                                                <td>{row.nama_barang}</td>
                                                <td>{row.stok} Pcs</td>
                                                <td>Rp. {row.harga.toLocaleString()}</td>
                                                <td>
                                                    <Link to={`/editbarang/${row.id}`} className="btn btn-sm btn-primary"><i class="bx bx-edit"></i> Edit</Link> &nbsp;
                                                    <Button onClick={()=>deleteBarang(row.id)} style={{backgroundColor: "red", borderColor: "red"}} className="btn btn-sm"><i class="bx bx-trash"></i> Hapus</Button>
                                                </td>
                                            </tr>
                                                    ))
                                                )
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    )

}

export default ListBarang;
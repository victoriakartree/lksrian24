import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button'
import axios from 'axios';
import Swal from 'sweetalert2';

import Header from '../../../templates/Header';
import Sidebar from '../../../templates/Sidebar';

function ListCustomer() {

    const [datacustomer, setDataCustomer] = useState([])

    useEffect(()=>{
        fetchDataCustomer() 
    },[])

    const fetchDataCustomer = async () => {
        await axios.get(`http://127.0.0.1:8000/api/customer`).then(({data})=>{
            setDataCustomer(data)
        })
    }

    const deleteCustomer = async (id) => {
        const isConfirm = await Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            return result.isConfirmed
          });

          if(!isConfirm){
            return;
          }

          await axios.delete(`http://127.0.0.1:8000/api/customer/destroy/${id}`).then(({data})=>{
            Swal.fire({
                icon:"success",
                text:data.message
            })
            fetchDataCustomer()
          }).catch(({response:{data}})=>{
            Swal.fire({
                text:data.message,
                icon:"error"
            })
          })
    }

	return (
		
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <Sidebar />
        
            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Data Customer</h4>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Data Customer</h5>
                                <Link to={"/createcustomer"} class="btn btn-sm btn-primary float-end"><i class="bx bx-plus"></i> Tambah Data</Link>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive text-nowrap">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Customer</th>
                                                <th>No Handphone</th>
                                                <th>Email</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                  				datacustomer.length > 0 && (
													datacustomer.map((row, key)=>(
                                            <tr key={key}>
                                                <td>{key + 1}</td>
                                                <td>{row.nama_customer}</td>
                                                <td>{row.nohp}</td>
                                                <td>{row.email}</td>
                                                <td>
                                                    <Link to={`/editcustomer/${row.id}`} className="btn btn-sm btn-primary"><i class="bx bx-edit"></i> Edit</Link> &nbsp;
                                                    <Button onClick={()=>deleteCustomer(row.id)} style={{backgroundColor: "red", borderColor: "red"}} className="btn btn-sm"><i class="bx bx-trash"></i> Hapus</Button>
                                                </td>
                                            </tr>
                                                    ))
                                                )
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    )

}

export default ListCustomer;
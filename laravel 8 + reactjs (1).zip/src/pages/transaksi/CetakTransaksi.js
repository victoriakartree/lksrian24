import React, { useEffect, useRef, useState } from "react";
import { useParams } from 'react-router-dom'
import axios from 'axios';
import moment from 'moment/moment';
import { useReactToPrint } from "react-to-print";

function CetakTransaksi() {

    const { id } = useParams()
    
    const [datatransaksi, setDataTransaksi] = useState([])

    const componentRef = useRef();
    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
        documentTitle: 'emp-data',
        // onAfterPrint: () => alert('Print Success')
    })

    useEffect(()=>{
        fetchDataTransaksi()
    },[])
    
    const fetchDataTransaksi = async () => {
        await axios.get(`http://127.0.0.1:8000/api/transaksi/cetak/${id}`).then(({data})=>{
            setDataTransaksi(data.transaksi)
            handlePrint()
        })
    }

    return (
                        <div class="row" ref={componentRef}>
                            <div class="col-xl">
                                <div class="card mb-12">
                                    <div class="card-body">
                                        {
                                  		    datatransaksi.length > 0 && (
												datatransaksi.map((row, key)=>(
                                                <div>
                                                    <div class="table-responsive text-nowrap">
                                                        <table class="table table-borderless">
                                                            <tbody>
                                                                <tr>
                                                                    <td>No Transaksi</td>
                                                                    <td>:</td>
                                                                    <td>{row.no_transaksi}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Customer</td>
                                                                    <td>:</td>
                                                                    <td>{row.nama_customer}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Tgl Transaksi</td>
                                                                    <td>:</td>
                                                                    <td>{moment(row.tgl_transaksi).format('d/MM/YYYY')}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <hr/>
                                                    <div class="table-responsive text-nowrap">
                                                        <table class="table table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th>Nama Barang</th>
                                                                    <th>Harga</th>
                                                                    <th>Qty</th>
                                                                    <th>Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>{row.nama_barang}</td>
                                                                    <td>Rp. {row.harga.toLocaleString()}</td>
                                                                    <td>{row.qty} Pcs</td>
                                                                    <td>Rp. {row.total.toLocaleString()}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                ))
                                            )
                                        }
                                    </div>
                                </div>
                            </div>        
                        </div>
    )
    
}

export default CetakTransaksi;
import React, { useState, useEffect } from "react";
import axios from 'axios'
import { useHistory } from 'react-router';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';

import Header from '../../templates/Header';
import SidebarKasir from '../../templates/SidebarKasir';

function CreateTransaksi() {

    const history = useHistory();
  
    const [id_customer, setIdCustomer] = useState("")
    const [id_barang, setIdBarang] = useState("")
    const [tgl_transaksi, setTglTransaksi] = useState("")
    const [qty, setQty] = useState("")
    // const [total_harga, setTotalHarga] = useState("")
    const [validationError,setValidationError] = useState({})

    const [newCustomerLists, setNewCustomerLists] =useState([]);
    const [newBarangLists, setNewBarangLists] =useState([]);
    
    const fetchCustomer = async () => {
    const response = await axios.get(`http://127.0.0.1:8000/api/customer`);
    
    setNewCustomerLists(response.data.map(customer => ({
         label: customer.nama_customer, 
         value: customer.id})))
    }
    
    useEffect(() => {
        fetchCustomer();
    }, []);

    const fetchBarang = async () => {
    const response = await axios.get(`http://127.0.0.1:8000/api/barang`);
        
    setNewBarangLists(response.data.map(barang => ({
        label: barang.nama_barang, 
        value: barang.id})))
    }
        
    useEffect(() => {
        fetchBarang();
    }, []);

    const [no_transaksi, setNoTransaksi] = useState([])

    useEffect(()=>{
        fetchNoTransaksi() 
    },[])

    const fetchNoTransaksi = async () => {
        await axios.get(`http://127.0.0.1:8000/api/getNoTransaksi`).then(({data})=>{
            setNoTransaksi(data)
        })
    }
    
    const createTransaksi = async (e) => {
        e.preventDefault();
  
        const formData = new FormData()
  
        formData.append('no_transaksi', no_transaksi)
        formData.append('id_customer', id_customer)
        formData.append('id_barang', id_barang)
        formData.append('tgl_transaksi', tgl_transaksi)
        formData.append('qty', qty)
        // formData.append('total_harga', total_harga)
  
        await axios.post(`http://127.0.0.1:8000/api/transaksi/store`, formData).then(({data})=>{
          Swal.fire({
              icon:"success",
              text:data.message
          })
          
          history.push('/listtransaksi');
          
        }).catch(({response})=>{
          if(response.status===422){
            setValidationError(response.data.errors)
          }else{
            Swal.fire({
              text:response.data.message,
              icon:"error"
            })
          }
        })
    }

    return (
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <SidebarKasir />
        
            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Create Data Barang</h4>
                        <div class="row">
                            <div class="col-xl">
                                <div class="card mb-12">
                                    {
                                        Object.keys(validationError).length > 0 && (
                                            <div className="row">
                                                <div className="col-12">
                                                    <div className="alert alert-danger">
                                                        <ul className="mb-0">
                                                            {
                                                            Object.entries(validationError).map(([key, value])=>(
                                                                <li key={key}>{value}</li>   
                                                            ))
                                                            }
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    }
                                    <Form onSubmit={createTransaksi}>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <Form.Label>No Transaksi</Form.Label>
                                            <Form.Control type="text" readOnly placeholder="No Transaksi ..." required value={no_transaksi} onChange={(event)=>{setNoTransaksi(event.target.value)}}/>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Customer</Form.Label>
                                            <Form.Select className="form-control" required value={id_customer} onChange={(event)=>{setIdCustomer(event.target.value)}}>
                                                <option value="" hidden>-- Pilih Customer --</option>
                                                {
                                                newCustomerLists.map(customer => 
                                                    <option key={customer.value} value={customer.value}> {customer.label}</option>
                                                )}
                                            </Form.Select>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Barang</Form.Label>
                                            <Form.Select className="form-control" required value={id_barang} onChange={(event)=>{setIdBarang(event.target.value)}}>
                                                <option value="" hidden>-- Pilih Barang --</option>
                                                {
                                                newBarangLists.map(barang => 
                                                    <option key={barang.value} value={barang.value}> {barang.label}</option>
                                                )}
                                            </Form.Select>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <Form.Label>Tgl Transaksi</Form.Label>
                                            <Form.Control type="date" required value={tgl_transaksi} onChange={(event)=>{setTglTransaksi(event.target.value)}}/>
                                        </div>

                                        <div class="mb-3">
                                            <Form.Label>Qty</Form.Label>
                                            <InputGroup className="mb-3">
                                                <Form.Control type="number" placeholder="Qty ..." required value={qty} onChange={(event)=>{setQty(event.target.value)}} />
                                                <InputGroup.Text>Pcs</InputGroup.Text>
                                            </InputGroup>
                                        </div>

                                        {/* <div class="mb-3">
                                            <Form.Label>Total Harga</Form.Label>
                                            <InputGroup className="mb-3">
                                                <InputGroup.Text>Rp</InputGroup.Text>
                                                <Form.Control type="number" placeholder="Total Harga ..." required value={total_harga} onChange={(event)=>{setTotalHarga(event.target.value)}} />
                                            </InputGroup>
                                        </div>       */}
                                    </div>
                                    <div class="card-footer">
                                        <Button className="btn btn-primary" type="submit"><i className="bx bx-save"></i> Save Changes</Button> &nbsp;&nbsp;
                                        <Link className="btn btn-danger" to={"/listtransaksi"}><i className="bx bx-undo"></i> Cancel</Link>
                                    </div>
                                    </Form>
                                </div>
                            </div>        
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    )

}

export default CreateTransaksi;
import React, { useEffect, useState } from "react";
import { useParams } from 'react-router-dom'
import axios from 'axios';
import { Link } from 'react-router-dom';
import moment from 'moment/moment';

import Header from '../../templates/Header';
import SidebarKasir from '../../templates/SidebarKasir';

function DetailTransaksi() {

    const { id } = useParams()

    const [datatransaksi, setDataTransaksi] = useState([])

    useEffect(()=>{
        fetchDataTransaksi()
    },[])
    
    const fetchDataTransaksi = async () => {
        await axios.get(`http://127.0.0.1:8000/api/transaksi/show/${id}`).then(({data})=>{
            setDataTransaksi(data.transaksi)
        })
    }

    return (
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <SidebarKasir />
        
            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Detail Data User</h4>
                        <div class="row">
                            <div class="col-xl">
                                <div class="card mb-12">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Detail Data Transaksi</h5>
                                        <Link to={"/listtransaksi"} class="btn btn-sm btn-primary float-end"><i class="bx bx-undo"></i> Kembali</Link>
                                    </div>
                                    <hr/>
                                    <div class="card-body">
                                        {
                                  		    datatransaksi.length > 0 && (
												datatransaksi.map((row, key)=>(
                                                <div>
                                                    <div class="table-responsive text-nowrap">
                                                        <table class="table table-borderless">
                                                            <tbody>
                                                                <tr>
                                                                    <td>No Transaksi</td>
                                                                    <td>:</td>
                                                                    <td>{row.no_transaksi}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Customer</td>
                                                                    <td>:</td>
                                                                    <td>{row.nama_customer}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Tgl Transaksi</td>
                                                                    <td>:</td>
                                                                    <td>{moment(row.tgl_transaksi).format('d/MM/YYYY')}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <hr/>
                                                    <div class="table-responsive text-nowrap">
                                                        <table class="table table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th>Nama Barang</th>
                                                                    <th>Harga</th>
                                                                    <th>Qty</th>
                                                                    <th>Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>{row.nama_barang}</td>
                                                                    <td>Rp. {row.harga.toLocaleString()}</td>
                                                                    <td>{row.qty} Pcs</td>
                                                                    <td>Rp. {row.total.toLocaleString()}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                ))
                                            )
                                        }
                                    </div>
                                </div>
                            </div>        
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    )

}

export default DetailTransaksi;
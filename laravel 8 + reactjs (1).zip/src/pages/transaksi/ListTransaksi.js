import React, { useEffect, useState,useRef } from 'react';
import { Link } from 'react-router-dom';

import axios from 'axios';
import moment from 'moment/moment';

import Header from '../../templates/Header';
import SidebarKasir from '../../templates/SidebarKasir';

function ListTransaksi() {

    const [datatransaksi, setDataTransaksi] = useState([])

    useEffect(()=>{
        fetchDataTransaksi() 
    },[])

    const fetchDataTransaksi = async () => {
        await axios.get(`http://127.0.0.1:8000/api/transaksi`).then(({data})=>{
            setDataTransaksi(data)
        })
    }

	return (
		
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <SidebarKasir />

            <div class="layout-page">
                <Header />

                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4">Data Transaksi</h4>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Data Transaksi</h5>
                                <Link to={"/createtransaksi"} class="btn btn-sm btn-primary float-end"><i class="bx bx-plus"></i> Tambah Data</Link>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive text-nowrap">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>No Transaksi</th>
                                                <th>Customer</th>
                                                <th>Tgl Transaksi</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                  				datatransaksi.length > 0 && (
													datatransaksi.map((row, key)=>(
                                            <tr key={key}>
                                                <td>{key + 1}</td>
                                                <td>{row.no_transaksi}</td>
                                                <td>{row.nama_customer}</td>
                                                <td>{moment(row.tgl_transaksi).format('d/MM/YYYY')}</td>
                                                <td>Rp. {row.total.toLocaleString()}</td>
                                                <td>
                                                    <Link to={`/detail/${row.id}`} className="btn btn-sm btn-success">Detail</Link> &nbsp;
                                                    <Link to={`/cetak/${row.id}`} target="_blank" className="btn btn-sm btn-secondary">Cetak</Link>
                                                </td>
                                            </tr>
                                                    ))
                                                )
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="content-backdrop fade"></div>
                </div>
            </div>
        </div>
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    )

}

export default ListTransaksi;
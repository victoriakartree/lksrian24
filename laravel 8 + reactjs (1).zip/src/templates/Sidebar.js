import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { useHistory } from 'react-router';
import axios from 'axios';
import Swal from 'sweetalert2';

function Sidebar() {

    const [user, setUser] = useState({});

    const history = useHistory();

    const token = localStorage.getItem("token");

    const fetchData = async () => {

        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
        await axios.get('http://127.0.0.1:8000/api/user')
        .then((response) => {

            setUser(response.data);
        })
    }

    useEffect(() => {

        if(!token) {

            history.push('/');
        }
        
        fetchData();
    }, []);

    const logoutHanlder = async () => {

        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
        await axios.post('http://127.0.0.1:8000/api/logout')
        .then((response) => {

            localStorage.removeItem("token");
            Swal.fire({
                icon:"success",
                text:response.data.message
            })
            history.push('/');
        });
    };

	return (
		
    <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
            <Link to={"#"} class="app-brand-link">
                <span class="app-brand-logo demo"></span>
                <span class="app-brand-text demo menu-text fw-bolder ms-2">React App</span>
            </Link>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">
            <li class="menu-item">
                <Link to={"/dashboard"} class="menu-link">
                    <i class="menu-icon tf-icons bx bx-home-circle"></i>
                    <div data-i18n="Analytics">Dashboard</div>
                </Link>
            </li>

            <li class="menu-header small text-uppercase">
                <span class="menu-header-text">Components</span>
            </li>
            
            
            <li class="menu-item">
                <Link to={"/listuser"} class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user-circle"></i>
                    <div data-i18n="Analytics">Data User</div>
                </Link>
            </li>
            
            <li class="menu-item">
                <Link to={"/listcustomer"} class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user"></i>
                    <div data-i18n="Analytics">Data Customer</div>
                </Link>
            </li>
            
            <li class="menu-item">
                <Link to={"/listbarang"} class="menu-link">
                    <i class="menu-icon tf-icons bx bx-briefcase"></i>
                    <div data-i18n="Analytics">Data Barang</div>
                </Link>
            </li>  

            <li class="menu-item">
                <Link onClick={logoutHanlder} class="menu-link">
                    <i class="menu-icon tf-icons bx bx-log-in-circle"></i>
                    <div data-i18n="Analytics">Logout</div>
                </Link>
            </li>
        </ul>
    </aside>

    )

}

export default Sidebar;